<?php
// api/toggle.php
session_start();
require_once __DIR__ . '/../db.php';
if (empty($_SESSION['admin_logged'])) { http_response_code(401); echo json_encode(['status'=>'error','message'=>'No autorizado']); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);
$status = ($input['status'] === 'paused') ? 'paused' : 'active';
if(!$id){ http_response_code(400); echo json_encode(['status'=>'error','message'=>'Missing id']); exit; }

$stmt = $pdo->prepare('UPDATE webrtc_users SET status=? WHERE id=?');
try{ $stmt->execute([$status,$id]); echo json_encode(['status'=>'ok']); }catch(Exception $e){ http_response_code(500); echo json_encode(['status'=>'error','message'=>$e->getMessage()]); }

